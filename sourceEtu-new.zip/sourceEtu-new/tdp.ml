open Type
open Ast
open Exceptions
open Tds

type table_param = (string, AstSyntax.defaut option list) Hashtbl.t

type analyse_expression = Tds.tds -> AstSyntax.expression -> (Tds.tds * table_param) -> AstTds.expression

(* Création d'une nouvelle table de paramètres *)
let creer_tdp () = 
  Hashtbl.create 100

(* Vérification des paramètres par défaut *)
let verifier_params_defaut params =
  let rec verifier acc has_default = function
    | [] -> List.rev acc
    | (_, _, Some d)::reste -> 
        verifier (Some d :: acc) true reste
    | (_, _, None)::reste ->
        if has_default then
          raise (MauvaiseUtilisationIdentifiant "Paramètre sans valeur par défaut après un paramètre avec valeur par défaut")
        else
          verifier (None :: acc) false reste
  in
  verifier [] false params

(* Ajout des paramètres par défaut dans la table *)
let ajouter_params nom params tdp =
  let defauts = List.map (fun (_, _, d) -> d) params in
  let valide = verifier_params_defaut params in
  Hashtbl.replace tdp nom valide

(* Compléter la liste des arguments avec valeurs par défaut *)
let completer_arguments analyse_tds_expr tds_courante tds_main tdp args nom =
  let defauts = 
    try Hashtbl.find tdp nom 
    with Not_found -> [] in
  
  let rec completer args_list defauts_list =
    match args_list, defauts_list with
    | [], [] -> []
    | [], (Some (AstSyntax.Defaut expr))::reste_defauts ->
        let expr_analysee = analyse_tds_expr tds_main expr (tds_courante, tdp) in
        expr_analysee :: completer [] reste_defauts
    | [], None::reste_defauts ->
        completer [] reste_defauts
    | arg::reste_args, _::reste_defauts ->
        arg :: completer reste_args reste_defauts
    | arg::reste_args, [] ->
        arg :: completer reste_args []
  in
  completer args defauts